package com.itsqmet.aplicativoweb.controller;
import com.itsqmet.aplicativoweb.model.Docente;import com.itsqmet.aplicativoweb.repository.DocenteRepository;import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/docentes") public class DocenteController extends BaseCrudController<Docente>{public DocenteController(DocenteRepository repo){super(repo);}}
