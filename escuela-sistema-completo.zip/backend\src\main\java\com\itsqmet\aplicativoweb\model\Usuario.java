package com.itsqmet.aplicativoweb.model;
import com.fasterxml.jackson.annotation.JsonProperty;import jakarta.persistence.*;import jakarta.validation.constraints.*;import lombok.*;
@Entity @Getter @Setter @NoArgsConstructor
public class Usuario {@Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;@NotBlank @Column(unique=true) private String usuario;@NotBlank @JsonProperty(access=JsonProperty.Access.WRITE_ONLY) private String password;@NotBlank private String estado="Activo";@ManyToOne(optional=false) private Rol rol;}
