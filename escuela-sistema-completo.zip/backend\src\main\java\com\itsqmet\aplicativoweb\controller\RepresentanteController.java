package com.itsqmet.aplicativoweb.controller;
import com.itsqmet.aplicativoweb.model.Representante;import com.itsqmet.aplicativoweb.repository.RepresentanteRepository;import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/representantes") public class RepresentanteController extends BaseCrudController<Representante>{public RepresentanteController(RepresentanteRepository repo){super(repo);}}
