﻿import { Link, Navigate } from "react-router-dom";
import MainLayout from "../../layouts/MainLayout";
import Card from "../../components/common/Card";
import "./Home.css";

interface ModuleCard {
  title: string;
  description: string;
  icon: string;
  path: string;
  colorClass: string;
  permission: string;
}

const modules: ModuleCard[] = [
  {
    title: "Gestion de usuarios",
    description: "Crear cuentas y asignar roles a los usuarios.",
    icon: "bi-person-gear",
    path: "/usuarios",
    permission: "Gestion de roles",
    colorClass: "roles-card",
  },
  {
    title: "GestiÃ³n de roles",
    description: "Administrar los permisos y roles de los usuarios.",
    icon: "bi-people-fill",
    path: "/roles",
    permission: "Gestion de roles",
    colorClass: "roles-card",
  },
  {
    title: "Ingreso de notas",
    description: "Registrar y actualizar las calificaciones acadÃ©micas.",
    icon: "bi-journal-check",
    path: "/notas",
    permission: "Notas",
    colorClass: "grades-card",
  },
  {
    title: "Asistencia",
    description: "Registrar la asistencia diaria de los estudiantes.",
    icon: "bi-calendar-check-fill",
    path: "/asistencia",
    permission: "Asistencia",
    colorClass: "attendance-card",
  },
  {
    title: "Padres de familia",
    description: "Consultar las calificaciones de los estudiantes.",
    icon: "bi-person-hearts",
    path: "/padres",
    permission: "Notas",
    colorClass: "parents-card",
  },
  {
    title: "Ingreso de representantes",
    description: "Registrar y administrar los representantes de estudiantes.",
    icon: "bi-person-vcard-fill",
    path: "/ingreso-padres",
    permission: "Representantes",
    colorClass: "parents-card",
  },
    {
    title: "Mensajes",
    description: "Enviar mensajes a los cursos",
    icon: "bi-chat-left-text-fill",
    path: "/mensajes",
    permission: "Mensajes",
    colorClass: "messages-card",
    },
  {
    title: "Ingreso de estudiantes",
    description: "Registrar y consultar la informaciÃ³n de los estudiantes.",
    icon: "bi-person-plus-fill",
    path: "/estudiantes",
    permission: "Estudiantes",
    colorClass: "students-card",
  },
  {
  title: "Registro de docentes",
  description: "Registrar, editar y administrar la informaciÃ³n de los docentes.",
  icon: "bi-person-badge-fill",
  path: "/docentes",
  permission: "Docentes",
  colorClass: "teachers-card",
},
];

function Home() {
  const autenticado =
    localStorage.getItem("usuarioAutenticado") === "true";

  if (!autenticado) {
    return <Navigate to="/login" replace />;
  }

  const nombreUsuario =
    localStorage.getItem("nombreUsuario") || "Usuario";
  const permisos: string[] = JSON.parse(localStorage.getItem("permisosUsuario") ?? "[]");
  const modulosVisibles = modules.filter((modulo) => permisos.includes(modulo.permission));

  return (
    <MainLayout>
      <div className="home-content">
        <section className="welcome-section">
          <div>
            <p className="welcome-label">Panel principal</p>

            <h1>Bienvenido, {nombreUsuario}</h1>

            <p>
              Administra la informaciÃ³n acadÃ©mica de la Escuela de
              EducaciÃ³n BÃ¡sica RepÃºblica de Venezuela.
            </p>
          </div>

          <div className="welcome-icon">
            <i className="bi bi-mortarboard-fill"></i>
          </div>
        </section>

        <section className="institution-section">
          <Card as="article" className="institution-card">
            <div className="institution-icon">
              <i className="bi bi-bullseye"></i>
            </div>

            <div>
              <h2>MisiÃ³n</h2>

              <p>
                Formar estudiantes con valores, pensamiento crÃ­tico,
                responsabilidad y compromiso social mediante una educaciÃ³n
                integral y de calidad.
              </p>
            </div>
          </Card>

          <Card as="article" className="institution-card">
            <div className="institution-icon">
              <i className="bi bi-eye-fill"></i>
            </div>

            <div>
              <h2>VisiÃ³n</h2>

              <p>
                Ser una instituciÃ³n reconocida por su excelencia acadÃ©mica,
                innovaciÃ³n educativa y formaciÃ³n de ciudadanos Ã­ntegros.
              </p>
            </div>
          </Card>
        </section>

        <br />

        <section className="modules-section">
          <div className="section-title">
            <p>Accesos rÃ¡pidos</p>
            <h2>MÃ³dulos del sistema</h2>
          </div>

          <div className="modules-grid">
            {modulosVisibles.map((module) => (
              <Link
                to={module.path}
                className={`module-card ${module.colorClass}`}
                key={module.title}
              >
                <div className="module-icon">
                  <i className={`bi ${module.icon}`}></i>
                </div>

                <div className="module-information">
                  <h3>{module.title}</h3>
                  <p>{module.description}</p>

                  <span>
                    Ingresar
                    <i className="bi bi-arrow-right"></i>
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </MainLayout>
  );
}

export default Home;

