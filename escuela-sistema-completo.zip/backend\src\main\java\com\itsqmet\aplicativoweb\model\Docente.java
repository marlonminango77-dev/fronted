package com.itsqmet.aplicativoweb.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;import jakarta.persistence.*;import jakarta.validation.constraints.*;import lombok.*;import java.time.LocalDate;
@Entity @Getter @Setter @NoArgsConstructor
public class Docente {@Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;@NotBlank @Column(unique=true,length=10) private String cedula;@NotBlank private String nombres;@NotBlank private String apellidos;@NotNull private LocalDate fechaNacimiento;@NotBlank private String especialidad;@NotBlank private String titulo;@NotBlank private String telefono;@Email @NotBlank @Column(unique=true) private String correo;@ManyToOne(optional=false) @JsonIgnoreProperties({"permisos"}) private Rol rol;}
