package com.itsqmet.aplicativoweb.controller;
import com.itsqmet.aplicativoweb.model.Mensaje;import com.itsqmet.aplicativoweb.repository.MensajeRepository;import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/mensajes") public class MensajeController extends BaseCrudController<Mensaje>{public MensajeController(MensajeRepository repo){super(repo);}}
