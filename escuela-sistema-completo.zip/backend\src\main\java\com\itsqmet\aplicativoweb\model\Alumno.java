package com.itsqmet.aplicativoweb.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;import jakarta.persistence.*;import jakarta.validation.constraints.*;import lombok.*;import java.time.LocalDate;
@Entity @Getter @Setter @NoArgsConstructor
public class Alumno {@Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;@NotBlank @Column(unique=true,length=10) private String cedula;@NotBlank private String nombres;@NotBlank private String apellidos;@NotNull private LocalDate fechaNacimiento;@NotBlank private String grado;@NotBlank private String paralelo;private String representante;@NotBlank private String telefono;private String estado="Activo";@ManyToOne @JsonIgnoreProperties({"alumnos"}) private Representante representanteRegistro;}
