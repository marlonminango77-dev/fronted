package com.itsqmet.aplicativoweb.controller;
import com.itsqmet.aplicativoweb.model.Materia;import com.itsqmet.aplicativoweb.repository.MateriaRepository;import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/materias") public class MateriaController extends BaseCrudController<Materia>{public MateriaController(MateriaRepository repo){super(repo);}}
