﻿-- Ejecutar conectado como usuario administrador de PostgreSQL.
-- La contraseña del usuario escuela_app debe cambiarse antes de ejecutar.

CREATE ROLE escuela_app WITH LOGIN PASSWORD 'CAMBIAR_POR_UNA_CONTRASENA_SEGURA';
CREATE DATABASE vinculacion OWNER escuela_app;

\connect vinculacion

GRANT ALL ON SCHEMA public TO escuela_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT ALL PRIVILEGES ON TABLES TO escuela_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT ALL PRIVILEGES ON SEQUENCES TO escuela_app;
