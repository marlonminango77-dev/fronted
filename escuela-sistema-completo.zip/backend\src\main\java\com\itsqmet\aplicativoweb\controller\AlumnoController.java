package com.itsqmet.aplicativoweb.controller;
import com.itsqmet.aplicativoweb.model.Alumno;import com.itsqmet.aplicativoweb.repository.AlumnoRepository;import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/alumnos") public class AlumnoController extends BaseCrudController<Alumno>{public AlumnoController(AlumnoRepository repo){super(repo);}}
