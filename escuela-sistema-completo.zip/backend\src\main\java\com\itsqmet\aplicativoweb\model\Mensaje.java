package com.itsqmet.aplicativoweb.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;import jakarta.persistence.*;import jakarta.validation.constraints.*;import lombok.*;import java.time.LocalDate;
@Entity @Getter @Setter @NoArgsConstructor
public class Mensaje {@Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;@NotNull private LocalDate fecha;@NotBlank private String curso;@NotBlank @Column(length=2000) private String contenido;private String estado="Enviado";@ManyToOne @JsonIgnoreProperties({"rol"}) private Docente remitente;}
