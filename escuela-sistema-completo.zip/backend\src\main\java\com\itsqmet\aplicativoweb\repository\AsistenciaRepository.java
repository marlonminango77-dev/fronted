package com.itsqmet.aplicativoweb.repository;
import com.itsqmet.aplicativoweb.model.Asistencia;import org.springframework.data.jpa.repository.JpaRepository;import java.time.LocalDate;import java.util.*;
public interface AsistenciaRepository extends JpaRepository<Asistencia,Long>{Optional<Asistencia> findByAlumnoIdAndFechaAndMateriaId(Long alumnoId,LocalDate fecha,Long materiaId);List<Asistencia> findByFechaAndMateriaId(LocalDate fecha,Long materiaId);}
