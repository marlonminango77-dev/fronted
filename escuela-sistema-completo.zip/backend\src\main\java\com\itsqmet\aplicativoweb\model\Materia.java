package com.itsqmet.aplicativoweb.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;import jakarta.persistence.*;import jakarta.validation.constraints.*;import lombok.*;
@Entity @Getter @Setter @NoArgsConstructor
public class Materia {@Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;@NotBlank @Column(unique=true) private String nombre;@NotBlank @Column(length=300) private String descripcion;private String grado;@ManyToOne @JsonIgnoreProperties({"rol"}) private Docente docente;}
