# Backend del Sistema Academico

API Spring Boot compatible con el frontend de la Escuela Republica de Venezuela.

## Requisitos

- Java 17 o superior
- PostgreSQL
- Base de datos `vinculacion`

## Configuracion

Configure estas variables de entorno antes del primer inicio:

- `DB_URL` (por defecto `jdbc:postgresql://localhost:5432/vinculacion`)
- `DB_USERNAME` (por defecto `postgres`)
- `DB_PASSWORD` (sin valor predeterminado)
- `APP_ADMIN_USERNAME` y `APP_ADMIN_PASSWORD` para crear el primer administrador
- `SERVER_PORT` (por defecto `8080`)
- `DDL_AUTO` (por defecto `update`)

No se incluyen contrasenas reales en el repositorio. Use `.env.example` como referencia.

## Ejecucion

```powershell
.\mvnw.cmd spring-boot:run
```

## Autenticacion segura

La API usa sesion, cookie `JSESSIONID` y CSRF. El frontend debe enviar credenciales (`withCredentials: true`).

1. `GET /api/auth/csrf`
2. Leer `token` y `headerName`.
3. Enviar el token en ese encabezado para `POST`, `PUT` y `DELETE`.
4. `POST /api/auth/login` con `{ "usuario": "...", "password": "..." }`.
5. `GET /api/auth/me` consulta la sesion.
6. `POST /api/auth/logout` cierra la sesion.

## Recursos CRUD

Cada recurso admite `GET /api/recurso`, `GET /{id}`, `POST`, `PUT /{id}` y `DELETE /{id}`:

- `/api/roles`
- `/api/usuarios`
- `/api/docentes`
- `/api/alumnos`
- `/api/representantes`
- `/api/materias`
- `/api/actividades`
- `/api/notas`
- `/api/asistencias`
- `/api/mensajes`

## Notas parciales

`POST /api/notas/lote`

```json
{
  "actividadId": 1,
  "notas": [
    { "alumnoId": 1, "calificacion": 9.5, "observacion": "Buen trabajo" },
    { "alumnoId": 2, "calificacion": null, "observacion": "" }
  ]
}
```

Una calificacion `null` no crea una nota y elimina la existente para esa actividad. Esto permite guardar solo una o varias notas.

## Asistencia por lote

`POST /api/asistencias/lote`

```json
{
  "fecha": "2026-07-28",
  "materiaId": 1,
  "estudiantes": [
    { "alumnoId": 1, "presente": true, "observacion": "" }
  ]
}
```

## Pruebas

```powershell
.\mvnw.cmd test
```

Las pruebas usan H2 en memoria y no modifican PostgreSQL.