package com.itsqmet.aplicativoweb.repository;
import com.itsqmet.aplicativoweb.model.Nota;import org.springframework.data.jpa.repository.JpaRepository;import java.util.*;
public interface NotaRepository extends JpaRepository<Nota,Long>{Optional<Nota> findByAlumnoIdAndActividadId(Long alumnoId,Long actividadId);List<Nota> findByActividadId(Long actividadId);}
