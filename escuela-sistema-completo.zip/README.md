﻿# Sistema Académico completo

Contenido:

- `frontend/`: aplicación React + Vite.
- `backend/`: API Spring Boot.
- `database/setup-postgresql.sql`: creación inicial de PostgreSQL.

No se incluyen contraseñas reales, repositorios `.git`, dependencias, compilados ni logs.

Consulta los archivos `.env.example` y `backend/README.md` para configurar y ejecutar el sistema.
