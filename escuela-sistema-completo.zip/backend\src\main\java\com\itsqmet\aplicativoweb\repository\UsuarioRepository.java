package com.itsqmet.aplicativoweb.repository;
import com.itsqmet.aplicativoweb.model.Usuario;import org.springframework.data.jpa.repository.JpaRepository;import java.util.Optional;
public interface UsuarioRepository extends JpaRepository<Usuario,Long>{Optional<Usuario> findByUsuarioIgnoreCase(String usuario);long countByRolId(Long rolId);}
