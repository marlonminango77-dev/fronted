package com.itsqmet.aplicativoweb.model;
import jakarta.persistence.*;import jakarta.validation.constraints.*;import lombok.*;import java.util.*;
@Entity @Getter @Setter @NoArgsConstructor
public class Rol {@Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;@NotBlank @Column(unique=true) private String nombre;@NotBlank @Column(length=300) private String descripcion;@NotBlank private String estado="Activo";private boolean protegido;@Transient private long usuarios;@ElementCollection(fetch=FetchType.EAGER) @CollectionTable(name="rol_permisos",joinColumns=@JoinColumn(name="rol_id")) @Column(name="permiso") private Set<String> permisos=new LinkedHashSet<>();}
