package com.itsqmet.aplicativoweb.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;import jakarta.persistence.*;import jakarta.validation.constraints.*;import lombok.*;import java.time.LocalDate;
@Entity @Getter @Setter @NoArgsConstructor
public class Actividad {@Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;@NotBlank private String nombre;@NotBlank private String tipo;@NotBlank private String periodo;private LocalDate fecha;@ManyToOne(optional=false) @JsonIgnoreProperties({"docente"}) private Materia materia;}
