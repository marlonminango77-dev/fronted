package com.itsqmet.aplicativoweb.controller;
import com.itsqmet.aplicativoweb.model.Actividad;import com.itsqmet.aplicativoweb.repository.ActividadRepository;import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/actividades") public class ActividadController extends BaseCrudController<Actividad>{public ActividadController(ActividadRepository repo){super(repo);}}
